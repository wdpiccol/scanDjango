"""scanProject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from cgitb import html
from django.contrib import admin
from django.urls import path
from django.views.generic import TemplateView
from scanApp.views import IdosoCreateView, CadastroUsuCreateViews
from scanApp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', views.login, name='login'),
    path('', views.menu, name=''),
    path('at_cad_idosos/', IdosoCreateView.as_view(), name='at_cad_idosos' ),
    path('controleInclusoesCsfv/', views.controle_incl_csfv, name='controleInclusoesCsfv'),
    path('controleEncaminhamentoReferenciaContrarreferencia/', views.controle_enc_ref_contr, name='controleEncaminhamentoReferenciaContrarreferencia'),
    path('cadastro_usuarios', CadastroUsuCreateViews.as_view(), name='cadastro_usuarios')
]
