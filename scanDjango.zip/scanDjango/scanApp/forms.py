from django import forms
from django.forms import ModelForm

from scanApp.models import cadastro

#class CadastroDeUsuarios(ModelForm):
#    class Meta:
#        model = cadastro
        
    
    