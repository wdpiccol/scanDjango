from django.contrib import admin
from .models import AtualizacaoCadastralIdosos, ControleInclusoesScfv, ControleEncaminhamentoReferenciaContrarreferencia, desengajamentos

admin.site.register(AtualizacaoCadastralIdosos)
admin.site.register(ControleInclusoesScfv)
admin.site.register(ControleEncaminhamentoReferenciaContrarreferencia)
admin.site.register(desengajamentos)

