from django.shortcuts import render
from django.views.generic.edit import CreateView
from django.http import HttpResponse
from scanApp.models import cadastro, AtualizacaoCadastralIdosos

def login(request):
    return render(request, 'scanAPP/sys_web_login.html')

def menu(request):
    return render(request, 'scanApp/sys_web_menu.html')

def at_cad_idosos(request):
    return render(request, 'scanApp/sys_web_at_cad_idosos.html')

def controle_incl_csfv(request):
    return render(request, 'scanApp/sys_web_controle_inclusoes_csfv.html')

def controle_enc_ref_contr(request):
    return render(request, 'scanApp/sys_web_controle_enc_ref_contr.html')

def cad_usu(request):
    return render(request, 'scanApp/sys_web_cad_usuarios.html')

class IdosoCreateView(CreateView):
    model = AtualizacaoCadastralIdosos
    fields = ['nome', 'situacao', 'diasQueFrequenta', 'dataAtualizacao']
    template_name = 'scanApp/sys_web_at_cad_idosos.html'

class CadastroUsuCreateViews(CreateView):
    model = cadastro
    fields = ['nome', 'endereco', 'telefone', 'dataNascimento', 'idade', 'cpf', 'rg', 'filiacao', 'estadoCivil', 'nomeUrgencia','telefoneUrgencia','parentesco','CRAS','telefoneCras','whats','NIS','UBS','cartaoSUS','problemaSaude','tratamento','renda','rendaAdicional','rendaProveniente','rendaFamiliar','tipoDeRenda','emprestimo','superEndividado','formasAcesso','tipoDemanda','participacao','turnoAtividades','atividades', 'outrosGrupos']
    template_name = 'scanApp/sys_web_cad_usuarios.html'
