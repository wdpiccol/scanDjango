from django.db import models

class demanda(models.Model):
    descricao = models.CharField(max_length = 400)

class tipoRenda(models.Model):
    descricao = models.CharField(max_length = 150)

class cadastro(models.Model):
    nome = models.CharField(max_length=100)
    endereco = models.CharField(max_length=600)
    telefone = models.CharField(max_length=90)
    dataNascimento = models.DateField()
    idade = models.IntegerField()
    cpf = models.CharField(max_length=30)
    rg = models.CharField(max_length=30)
    filiacao = models.CharField(max_length=400)
    estadoCivil = models.CharField(max_length=500)
    nomeUrgencia = models.CharField(max_length=100)
    telefoneUrgencia = models.CharField(max_length=90)
    parentesco = models.CharField(max_length=200)
    CRAS = models.CharField(max_length=250)
    telefoneCras = models.CharField(max_length=90)
    whats = models.CharField(max_length=90)
    NIS = models.IntegerField()
    UBS = models.CharField(max_length=250)
    cartaoSUS = models.CharField(max_length=150)
    problemaSaude = models.BooleanField()
    tratamento = models.CharField(max_length = 500)
    renda = models.CharField(max_length = 400)
    rendaAdicional = models.BooleanField()
    rendaProveniente = models.CharField(max_length = 700)
    rendaFamiliar = models.BooleanField()
    tipoDeRenda = models.ManyToManyField(tipoRenda)
    emprestimo = models.BooleanField()
    superEndividado = models.BooleanField()
    formasAcesso = models.CharField(max_length = 150)
    tipoDemanda = models.ManyToManyField(demanda)
    participacao = models.CharField(max_length = 200)
    turnoAtividades = models.CharField(max_length = 250)
    atividades = models.CharField(max_length = 150)
    outrosGrupos = models.BooleanField()



class AtualizacaoCadastralIdosos(models.Model):
    nome = models.CharField(max_length=100)
    situacao = models.CharField(max_length=100)
    diasQueFrequenta = models.CharField(max_length=100)
    dataAtualizacao = models.CharField(max_length=100)
    
class ControleInclusoesScfv(models.Model):
    usuario = models.CharField(max_length=100)
    dataInclusao = models.CharField(max_length=100)
    pontuacaoIvrs = models.CharField(max_length=100)
    cras = models.CharField(max_length=100)
    outros = models.CharField(max_length=100)
    
class ControleEncaminhamentoReferenciaContrarreferencia(models.Model):
    usuario = models.CharField(max_length=100)
    local = models.CharField(max_length=100)
    data = models.CharField(max_length=100)
    motivo = models.CharField(max_length=100)
    retorno = models.CharField(max_length=100)

class desengajamentos(models.Model):
    nome_usuario = models.CharField(max_length=200)
    data_nascimento = models.DateField()
    observacoes = models.CharField(max_length=10000)
 

    
